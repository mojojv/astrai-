"""
Dataset personalizado para el proyecto ASTRAI Cancer Detection.
"""

import os
import json
from typing import Optional, Tuple, Dict, Any, List
import torch
from torch.utils.data import Dataset
import cv2
import numpy as np
from torchvision import transforms
import torch.nn.functional as F

from ..core.logger import main_logger
from ..core.exceptions import DataProcessingError, ValidationError
from ..core.utils import validate_image_path
from .dicom_handler import DICOMHandler
from .preprocessing import ImagePreprocessor

class ThyroidDataset(Dataset):
    """
    Dataset personalizado para imágenes tiroideas con anotaciones.
    
    Soporta:
    - Imágenes en formatos PNG, JPG, JPEG, DICOM
    - Anotaciones en formato JSON
    - Transformaciones de datos
    - Generación de máscaras de segmentación
    - Clasificación TI-RADS
    """
    
    def __init__(
        self,
        data_dir: str,
        transform: Optional[transforms.Compose] = None,
        target_size: Tuple[int, int] = (512, 512),
        max_samples: Optional[int] = None,
        split: str = 'train'
    ):
        """
        Inicializa el dataset.
        
        Args:
            data_dir: Directorio con los datos
            transform: Transformaciones a aplicar
            target_size: Tamaño objetivo de las imágenes
            max_samples: Número máximo de muestras a cargar
            split: Tipo de split ('train', 'val', 'test')
        """
        self.data_dir = data_dir
        self.transform = transform
        self.target_size = target_size
        self.max_samples = max_samples
        self.split = split
        
        # Inicializar componentes
        self.dicom_handler = DICOMHandler()
        self.preprocessor = ImagePreprocessor()
        
        # Cargar datos
        self.image_paths = []
        self.annotations = []
        self._load_data()
        
        # Transformación por defecto
        self.default_transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Resize(target_size),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        main_logger.info(f"Dataset inicializado: {len(self.image_paths)} muestras en split '{split}'")
    
    def _load_data(self) -> None:
        """Carga las rutas de imágenes y anotaciones."""
        if not os.path.exists(self.data_dir):
            raise DataProcessingError(f"Directorio de datos no encontrado: {self.data_dir}")
        
        # Buscar imágenes recursivamente
        for root, _, files in os.walk(self.data_dir):
            for file in files:
                if self.max_samples and len(self.image_paths) >= self.max_samples:
                    break
                
                file_path = os.path.join(root, file)
                
                if validate_image_path(file_path):
                    self.image_paths.append(file_path)
                    
                    # Buscar anotación correspondiente
                    annotation_path = os.path.splitext(file_path)[0] + '.json'
                    if os.path.exists(annotation_path):
                        try:
                            with open(annotation_path, 'r', encoding='utf-8') as f:
                                annotation = json.load(f)
                            self.annotations.append(annotation)
                        except (json.JSONDecodeError, IOError) as e:
                            main_logger.warning(f"Error cargando anotación {annotation_path}: {e}")
                            self.annotations.append(None)
                    else:
                        self.annotations.append(None)
        
        if not self.image_paths:
            main_logger.warning(f"No se encontraron imágenes válidas en {self.data_dir}")
    
    def __len__(self) -> int:
        """Retorna el número de muestras en el dataset."""
        return len(self.image_paths)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, Optional[Dict[str, torch.Tensor]]]:
        """
        Obtiene una muestra del dataset.
        
        Args:
            idx: Índice de la muestra
            
        Returns:
            Tupla (imagen, target) donde target contiene las anotaciones
        """
        try:
            # Cargar imagen
            image_path = self.image_paths[idx]
            image = self._load_image(image_path)
            
            # Cargar anotaciones
            annotation = self.annotations[idx]
            target = self._process_annotation(image.shape, annotation) if annotation else None
            
            # Aplicar transformaciones
            if self.transform:
                image = self.transform(image)
            else:
                image = self.default_transform(image)
            
            # Redimensionar máscara de segmentación si existe
            if target and 'seg_mask' in target:
                seg_mask = target['seg_mask']
                # Redimensionar a tamaño objetivo
                seg_mask = seg_mask.unsqueeze(0).unsqueeze(0).float()
                seg_mask_resized = F.interpolate(
                    seg_mask, 
                    size=self.target_size, 
                    mode='nearest'
                )
                target['seg_mask'] = seg_mask_resized.squeeze().long()
            
            return image, target
            
        except Exception as e:
            main_logger.error(f"Error cargando muestra {idx}: {str(e)}")
            # Retornar muestra vacía en caso de error
            empty_image = torch.zeros((3, *self.target_size))
            return empty_image, None
    
    def _load_image(self, image_path: str) -> np.ndarray:
        """
        Carga una imagen desde el disco.
        
        Args:
            image_path: Ruta de la imagen
            
        Returns:
            Array de imagen en formato RGB
        """
        try:
            if image_path.lower().endswith(('.dcm', '.dicom')):
                image = self.dicom_handler.load_dicom_image(image_path)
            else:
                image = cv2.imread(image_path)
                if image is None:
                    raise DataProcessingError(f"No se pudo cargar la imagen: {image_path}")
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # Preprocesar imagen
            image = self.preprocessor.enhance_image(image)
            
            return image
            
        except Exception as e:
            raise DataProcessingError(f"Error cargando imagen {image_path}: {str(e)}")
    
    def _process_annotation(self, image_shape: Tuple[int, int, int], annotation: Dict[str, Any]) -> Dict[str, torch.Tensor]:
        """
        Procesa las anotaciones y genera las máscaras correspondientes.
        
        Args:
            image_shape: Forma de la imagen (H, W, C)
            annotation: Diccionario con las anotaciones
            
        Returns:
            Diccionario con tensores de anotaciones procesadas
        """
        h, w, _ = image_shape
        
        # Máscara de segmentación
        seg_mask = np.zeros((h, w), dtype=np.uint8)
        
        # Dibujar glándula tiroides (clase 1)
        if 'thyroid' in annotation:
            thyroid = annotation['thyroid']
            if 'position' in thyroid and 'width' in thyroid and 'height' in thyroid:
                center = (int(thyroid['position'][0]), int(thyroid['position'][1]))
                axes = (int(thyroid['width']//2), int(thyroid['height']//2))
                cv2.ellipse(seg_mask, center, axes, 0, 0, 360, 1, -1)
        
        # Dibujar nódulos (clase 2)
        for nodule in annotation.get('nodules', []):
            if 'bbox' in nodule:
                bbox = nodule['bbox']
                center = ((bbox[0] + bbox[2]) // 2, (bbox[1] + bbox[3]) // 2)
                radius = max(1, int((bbox[2] - bbox[0]) // 2))
                cv2.circle(seg_mask, center, radius, 2, -1)
        
        # Dibujar calcificaciones (clase 3)
        for calc in annotation.get('calcifications', []):
            if 'position' in calc and 'size' in calc:
                pos = (int(calc['position'][0]), int(calc['position'][1]))
                size = max(1, int(calc['size']))
                cv2.circle(seg_mask, pos, size, 3, -1)
        
        # Clase TI-RADS (convertir a índice 0-4)
        tirads = annotation.get('tirads', 2) - 1
        tirads = max(0, min(4, tirads))  # Asegurar rango válido
        
        return {
            'seg_mask': torch.tensor(seg_mask, dtype=torch.int64),
            'tirads': torch.tensor(tirads, dtype=torch.int64),
            'image_path': self.image_paths[self.annotations.index(annotation)] if annotation in self.annotations else ""
        }
    
    def get_class_weights(self) -> torch.Tensor:
        """
        Calcula pesos de clase para balancear el dataset.
        
        Returns:
            Tensor con pesos de clase
        """
        class_counts = torch.zeros(4)  # 4 clases de segmentación
        
        for i in range(len(self)):
            _, target = self[i]
            if target and 'seg_mask' in target:
                mask = target['seg_mask']
                for class_id in range(4):
                    class_counts[class_id] += (mask == class_id).sum().item()
        
        # Calcular pesos inversamente proporcionales a la frecuencia
        total_pixels = class_counts.sum()
        class_weights = total_pixels / (4 * class_counts + 1e-8)  # Evitar división por cero
        
        return class_weights
    
    def get_sample_info(self, idx: int) -> Dict[str, Any]:
        """
        Obtiene información de una muestra específica.
        
        Args:
            idx: Índice de la muestra
            
        Returns:
            Diccionario con información de la muestra
        """
        if idx >= len(self):
            raise IndexError(f"Índice {idx} fuera de rango")
        
        image_path = self.image_paths[idx]
        annotation = self.annotations[idx]
        
        info = {
            'index': idx,
            'image_path': image_path,
            'has_annotation': annotation is not None,
            'file_size': os.path.getsize(image_path) if os.path.exists(image_path) else 0
        }
        
        if annotation:
            info.update({
                'tirads': annotation.get('tirads', 'N/A'),
                'num_nodules': len(annotation.get('nodules', [])),
                'num_calcifications': len(annotation.get('calcifications', []))
            })
        
        return info

