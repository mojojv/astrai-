"""
Manejador de archivos DICOM para el proyecto ASTRAI Cancer Detection.
"""

import os
from typing import Tuple, Dict, Any, Optional
import numpy as np
import pydicom
from pydicom.pixel_data_handlers.util import apply_voi_lut

from ..core.logger import main_logger
from ..core.exceptions import DICOMProcessingError

class DICOMHandler:
    """
    Clase para manejar archivos DICOM médicos.
    
    Proporciona funcionalidades para:
    - Cargar archivos DICOM
    - Extraer metadatos médicos
    - Convertir a formatos estándar de imagen
    - Aplicar transformaciones específicas de DICOM
    """
    
    def __init__(self):
        """Inicializa el manejador DICOM."""
        self.supported_transfer_syntaxes = [
            '1.2.840.10008.1.2',      # Implicit VR Little Endian
            '1.2.840.10008.1.2.1',    # Explicit VR Little Endian
            '1.2.840.10008.1.2.2',    # Explicit VR Big Endian
        ]
    
    def load_dicom_image(self, file_path: str) -> np.ndarray:
        """
        Carga una imagen DICOM y la convierte a array RGB.
        
        Args:
            file_path: Ruta del archivo DICOM
            
        Returns:
            Array de imagen en formato RGB (H, W, 3)
            
        Raises:
            DICOMProcessingError: Si hay error al procesar el DICOM
        """
        try:
            # Verificar que el archivo existe
            if not os.path.exists(file_path):
                raise DICOMProcessingError(f"Archivo DICOM no encontrado: {file_path}")
            
            # Cargar archivo DICOM
            dicom_data = pydicom.dcmread(file_path)
            
            # Verificar que contiene datos de imagen
            if not hasattr(dicom_data, 'pixel_array'):
                raise DICOMProcessingError(f"El archivo DICOM no contiene datos de imagen: {file_path}")
            
            # Obtener array de píxeles
            pixel_array = dicom_data.pixel_array
            
            # Aplicar LUT de ventana si está disponible
            if hasattr(dicom_data, 'WindowCenter') and hasattr(dicom_data, 'WindowWidth'):
                pixel_array = apply_voi_lut(pixel_array, dicom_data)
            
            # Normalizar a rango 0-255
            pixel_array = self._normalize_pixel_array(pixel_array)
            
            # Convertir a RGB si es necesario
            if len(pixel_array.shape) == 2:
                # Imagen en escala de grises, convertir a RGB
                rgb_image = np.stack((pixel_array,) * 3, axis=-1)
            elif len(pixel_array.shape) == 3:
                # Ya es una imagen en color
                rgb_image = pixel_array
            else:
                raise DICOMProcessingError(f"Formato de imagen DICOM no soportado: {pixel_array.shape}")
            
            main_logger.info(f"Imagen DICOM cargada exitosamente: {file_path}")
            return rgb_image.astype(np.uint8)
            
        except pydicom.errors.InvalidDicomError as e:
            raise DICOMProcessingError(f"Archivo DICOM inválido {file_path}: {str(e)}")
        except Exception as e:
            raise DICOMProcessingError(f"Error procesando DICOM {file_path}: {str(e)}")
    
    def extract_metadata(self, file_path: str) -> Dict[str, Any]:
        """
        Extrae metadatos relevantes de un archivo DICOM.
        
        Args:
            file_path: Ruta del archivo DICOM
            
        Returns:
            Diccionario con metadatos extraídos
        """
        try:
            dicom_data = pydicom.dcmread(file_path)
            
            metadata = {
                'patient_id': getattr(dicom_data, 'PatientID', 'Unknown'),
                'patient_name': str(getattr(dicom_data, 'PatientName', 'Unknown')),
                'study_date': getattr(dicom_data, 'StudyDate', 'Unknown'),
                'modality': getattr(dicom_data, 'Modality', 'Unknown'),
                'manufacturer': getattr(dicom_data, 'Manufacturer', 'Unknown'),
                'institution_name': getattr(dicom_data, 'InstitutionName', 'Unknown'),
                'study_description': getattr(dicom_data, 'StudyDescription', 'Unknown'),
                'series_description': getattr(dicom_data, 'SeriesDescription', 'Unknown'),
                'image_type': getattr(dicom_data, 'ImageType', 'Unknown'),
                'pixel_spacing': getattr(dicom_data, 'PixelSpacing', None),
                'slice_thickness': getattr(dicom_data, 'SliceThickness', None),
                'rows': getattr(dicom_data, 'Rows', None),
                'columns': getattr(dicom_data, 'Columns', None),
                'bits_allocated': getattr(dicom_data, 'BitsAllocated', None),
                'bits_stored': getattr(dicom_data, 'BitsStored', None),
                'window_center': getattr(dicom_data, 'WindowCenter', None),
                'window_width': getattr(dicom_data, 'WindowWidth', None),
            }
            
            # Convertir listas a strings para facilitar el manejo
            for key, value in metadata.items():
                if isinstance(value, (list, pydicom.multival.MultiValue)):
                    metadata[key] = str(value)
            
            return metadata
            
        except Exception as e:
            main_logger.error(f"Error extrayendo metadatos de {file_path}: {str(e)}")
            return {}
    
    def _normalize_pixel_array(self, pixel_array: np.ndarray) -> np.ndarray:
        """
        Normaliza un array de píxeles al rango 0-255.
        
        Args:
            pixel_array: Array de píxeles original
            
        Returns:
            Array normalizado
        """
        # Convertir a float para evitar overflow
        pixel_array = pixel_array.astype(np.float64)
        
        # Normalizar al rango 0-255
        min_val = pixel_array.min()
        max_val = pixel_array.max()
        
        if max_val > min_val:
            normalized = (pixel_array - min_val) / (max_val - min_val) * 255.0
        else:
            normalized = np.zeros_like(pixel_array)
        
        return normalized
    
    def validate_dicom_file(self, file_path: str) -> bool:
        """
        Valida si un archivo es un DICOM válido.
        
        Args:
            file_path: Ruta del archivo
            
        Returns:
            True si es un DICOM válido, False en caso contrario
        """
        try:
            dicom_data = pydicom.dcmread(file_path)
            
            # Verificar que tiene datos de imagen
            if not hasattr(dicom_data, 'pixel_array'):
                return False
            
            # Verificar que el array de píxeles no está vacío
            if dicom_data.pixel_array.size == 0:
                return False
            
            return True
            
        except Exception:
            return False
    
    def get_image_info(self, file_path: str) -> Dict[str, Any]:
        """
        Obtiene información básica de una imagen DICOM.
        
        Args:
            file_path: Ruta del archivo DICOM
            
        Returns:
            Diccionario con información de la imagen
        """
        try:
            dicom_data = pydicom.dcmread(file_path)
            
            info = {
                'file_path': file_path,
                'file_size': os.path.getsize(file_path),
                'is_valid': self.validate_dicom_file(file_path),
                'modality': getattr(dicom_data, 'Modality', 'Unknown'),
                'dimensions': None,
                'pixel_spacing': getattr(dicom_data, 'PixelSpacing', None),
                'has_pixel_data': hasattr(dicom_data, 'pixel_array')
            }
            
            if info['has_pixel_data']:
                pixel_array = dicom_data.pixel_array
                info['dimensions'] = pixel_array.shape
                info['data_type'] = str(pixel_array.dtype)
                info['min_value'] = float(pixel_array.min())
                info['max_value'] = float(pixel_array.max())
            
            return info
            
        except Exception as e:
            return {
                'file_path': file_path,
                'file_size': os.path.getsize(file_path) if os.path.exists(file_path) else 0,
                'is_valid': False,
                'error': str(e)
            }
    
    def convert_to_standard_format(self, file_path: str, output_path: str, format: str = 'PNG') -> bool:
        """
        Convierte un archivo DICOM a un formato de imagen estándar.
        
        Args:
            file_path: Ruta del archivo DICOM
            output_path: Ruta de salida
            format: Formato de salida ('PNG', 'JPEG')
            
        Returns:
            True si la conversión fue exitosa
        """
        try:
            import cv2
            
            # Cargar imagen DICOM
            image = self.load_dicom_image(file_path)
            
            # Guardar en formato estándar
            if format.upper() == 'PNG':
                success = cv2.imwrite(output_path, cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
            elif format.upper() == 'JPEG':
                success = cv2.imwrite(output_path, cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
            else:
                raise DICOMProcessingError(f"Formato no soportado: {format}")
            
            if success:
                main_logger.info(f"DICOM convertido exitosamente: {file_path} -> {output_path}")
                return True
            else:
                raise DICOMProcessingError("Error guardando imagen convertida")
                
        except Exception as e:
            main_logger.error(f"Error convirtiendo DICOM {file_path}: {str(e)}")
            return False

