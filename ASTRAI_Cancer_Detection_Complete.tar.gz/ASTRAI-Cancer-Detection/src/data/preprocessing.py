"""
Módulo de preprocesamiento de imágenes para el proyecto ASTRAI Cancer Detection.
"""

import cv2
import numpy as np
from typing import Tuple, Optional, Union
from scipy import ndimage
from skimage import morphology, measure

from ..core.logger import main_logger
from ..core.exceptions import DataProcessingError

class ImagePreprocessor:
    """
    Clase para el preprocesamiento de imágenes médicas.
    
    Incluye técnicas específicas para imágenes tiroideas:
    - Mejora de contraste
    - Reducción de ruido
    - Normalización
    - Filtros específicos para ultrasonido
    """
    
    def __init__(self):
        """Inicializa el preprocesador de imágenes."""
        # Parámetros para CLAHE (Contrast Limited Adaptive Histogram Equalization)
        self.clahe_clip_limit = 3.0
        self.clahe_tile_grid_size = (8, 8)
        
        # Parámetros para filtro bilateral
        self.bilateral_d = 9
        self.bilateral_sigma_color = 75
        self.bilateral_sigma_space = 75
        
        # Parámetros para filtro gaussiano
        self.gaussian_kernel_size = (5, 5)
        self.gaussian_sigma = 1.0
    
    def enhance_image(self, image: np.ndarray) -> np.ndarray:
        """
        Aplica mejoras generales a una imagen médica.
        
        Args:
            image: Imagen de entrada (H, W, 3) en formato RGB
            
        Returns:
            Imagen mejorada
        """
        try:
            if len(image.shape) != 3 or image.shape[2] != 3:
                raise DataProcessingError(f"Formato de imagen inválido: {image.shape}")
            
            # Convertir a escala de grises para procesamiento
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
            
            # Aplicar CLAHE para mejorar contraste
            enhanced_gray = self._apply_clahe(gray)
            
            # Reducir ruido con filtro bilateral
            denoised = self._apply_bilateral_filter(enhanced_gray)
            
            # Fusionar con la imagen original
            enhanced_image = self._merge_with_original(image, denoised)
            
            return enhanced_image
            
        except Exception as e:
            main_logger.error(f"Error en mejora de imagen: {str(e)}")
            return image  # Retornar imagen original en caso de error
    
    def _apply_clahe(self, gray_image: np.ndarray) -> np.ndarray:
        """
        Aplica CLAHE (Contrast Limited Adaptive Histogram Equalization).
        
        Args:
            gray_image: Imagen en escala de grises
            
        Returns:
            Imagen con contraste mejorado
        """
        clahe = cv2.createCLAHE(
            clipLimit=self.clahe_clip_limit,
            tileGridSize=self.clahe_tile_grid_size
        )
        return clahe.apply(gray_image)
    
    def _apply_bilateral_filter(self, image: np.ndarray) -> np.ndarray:
        """
        Aplica filtro bilateral para reducir ruido preservando bordes.
        
        Args:
            image: Imagen de entrada
            
        Returns:
            Imagen filtrada
        """
        return cv2.bilateralFilter(
            image,
            self.bilateral_d,
            self.bilateral_sigma_color,
            self.bilateral_sigma_space
        )
    
    def _merge_with_original(self, original_rgb: np.ndarray, enhanced_gray: np.ndarray) -> np.ndarray:
        """
        Fusiona la imagen mejorada con la original manteniendo información de color.
        
        Args:
            original_rgb: Imagen original en RGB
            enhanced_gray: Imagen mejorada en escala de grises
            
        Returns:
            Imagen fusionada en RGB
        """
        # Convertir original a LAB
        lab = cv2.cvtColor(original_rgb, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        
        # Reemplazar canal L con la versión mejorada
        merged_lab = cv2.merge((enhanced_gray, a, b))
        
        # Convertir de vuelta a RGB
        result = cv2.cvtColor(merged_lab, cv2.COLOR_LAB2RGB)
        
        return result
    
    def normalize_intensity(self, image: np.ndarray, target_range: Tuple[float, float] = (0.0, 1.0)) -> np.ndarray:
        """
        Normaliza la intensidad de una imagen al rango especificado.
        
        Args:
            image: Imagen de entrada
            target_range: Rango objetivo (min, max)
            
        Returns:
            Imagen normalizada
        """
        try:
            image_float = image.astype(np.float32)
            
            # Calcular min y max actuales
            current_min = image_float.min()
            current_max = image_float.max()
            
            if current_max > current_min:
                # Normalizar al rango [0, 1]
                normalized = (image_float - current_min) / (current_max - current_min)
                
                # Escalar al rango objetivo
                target_min, target_max = target_range
                scaled = normalized * (target_max - target_min) + target_min
            else:
                # Imagen uniforme, asignar valor mínimo del rango
                scaled = np.full_like(image_float, target_range[0])
            
            return scaled
            
        except Exception as e:
            main_logger.error(f"Error en normalización: {str(e)}")
            return image.astype(np.float32)
    
    def remove_artifacts(self, image: np.ndarray) -> np.ndarray:
        """
        Remueve artefactos comunes en imágenes de ultrasonido.
        
        Args:
            image: Imagen de entrada
            
        Returns:
            Imagen sin artefactos
        """
        try:
            # Convertir a escala de grises si es necesario
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
            else:
                gray = image.copy()
            
            # Aplicar filtro mediano para remover ruido impulsivo
            median_filtered = cv2.medianBlur(gray, 5)
            
            # Aplicar morfología para remover pequeños artefactos
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
            opened = cv2.morphologyEx(median_filtered, cv2.MORPH_OPEN, kernel)
            
            # Si la imagen original era RGB, convertir de vuelta
            if len(image.shape) == 3:
                result = cv2.cvtColor(opened, cv2.COLOR_GRAY2RGB)
            else:
                result = opened
            
            return result
            
        except Exception as e:
            main_logger.error(f"Error removiendo artefactos: {str(e)}")
            return image
    
    def enhance_edges(self, image: np.ndarray, method: str = 'sobel') -> np.ndarray:
        """
        Realza los bordes en una imagen.
        
        Args:
            image: Imagen de entrada
            method: Método de detección de bordes ('sobel', 'canny', 'laplacian')
            
        Returns:
            Imagen con bordes realzados
        """
        try:
            # Convertir a escala de grises
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
            else:
                gray = image.copy()
            
            if method == 'sobel':
                # Gradientes Sobel
                grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
                grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
                edges = np.sqrt(grad_x**2 + grad_y**2)
                
            elif method == 'canny':
                # Detector de bordes Canny
                edges = cv2.Canny(gray, 50, 150)
                
            elif method == 'laplacian':
                # Filtro Laplaciano
                edges = cv2.Laplacian(gray, cv2.CV_64F)
                edges = np.abs(edges)
                
            else:
                raise ValueError(f"Método no soportado: {method}")
            
            # Normalizar al rango 0-255
            edges_normalized = cv2.normalize(edges, None, 0, 255, cv2.NORM_MINMAX)
            edges_uint8 = edges_normalized.astype(np.uint8)
            
            # Combinar con imagen original
            if len(image.shape) == 3:
                # Convertir bordes a RGB y combinar
                edges_rgb = cv2.cvtColor(edges_uint8, cv2.COLOR_GRAY2RGB)
                enhanced = cv2.addWeighted(image, 0.7, edges_rgb, 0.3, 0)
            else:
                enhanced = cv2.addWeighted(gray, 0.7, edges_uint8, 0.3, 0)
            
            return enhanced
            
        except Exception as e:
            main_logger.error(f"Error realzando bordes: {str(e)}")
            return image
    
    def resize_with_aspect_ratio(
        self, 
        image: np.ndarray, 
        target_size: Tuple[int, int], 
        interpolation: int = cv2.INTER_LINEAR
    ) -> np.ndarray:
        """
        Redimensiona una imagen manteniendo la relación de aspecto.
        
        Args:
            image: Imagen de entrada
            target_size: Tamaño objetivo (width, height)
            interpolation: Método de interpolación
            
        Returns:
            Imagen redimensionada
        """
        try:
            h, w = image.shape[:2]
            target_w, target_h = target_size
            
            # Calcular factor de escala
            scale = min(target_w / w, target_h / h)
            
            # Nuevas dimensiones
            new_w = int(w * scale)
            new_h = int(h * scale)
            
            # Redimensionar
            resized = cv2.resize(image, (new_w, new_h), interpolation=interpolation)
            
            # Crear imagen con padding si es necesario
            if new_w != target_w or new_h != target_h:
                # Calcular padding
                pad_w = (target_w - new_w) // 2
                pad_h = (target_h - new_h) // 2
                
                # Aplicar padding
                if len(image.shape) == 3:
                    padded = cv2.copyMakeBorder(
                        resized, pad_h, target_h - new_h - pad_h, 
                        pad_w, target_w - new_w - pad_w,
                        cv2.BORDER_CONSTANT, value=[0, 0, 0]
                    )
                else:
                    padded = cv2.copyMakeBorder(
                        resized, pad_h, target_h - new_h - pad_h,
                        pad_w, target_w - new_w - pad_w,
                        cv2.BORDER_CONSTANT, value=0
                    )
                
                return padded
            
            return resized
            
        except Exception as e:
            main_logger.error(f"Error redimensionando imagen: {str(e)}")
            return cv2.resize(image, target_size, interpolation=interpolation)
    
    def apply_windowing(
        self, 
        image: np.ndarray, 
        window_center: float, 
        window_width: float
    ) -> np.ndarray:
        """
        Aplica windowing (ventana) a una imagen médica.
        
        Args:
            image: Imagen de entrada
            window_center: Centro de la ventana
            window_width: Ancho de la ventana
            
        Returns:
            Imagen con windowing aplicado
        """
        try:
            # Convertir a float para cálculos
            image_float = image.astype(np.float32)
            
            # Calcular límites de la ventana
            window_min = window_center - window_width / 2
            window_max = window_center + window_width / 2
            
            # Aplicar windowing
            windowed = np.clip(image_float, window_min, window_max)
            
            # Normalizar al rango 0-255
            if window_max > window_min:
                windowed = (windowed - window_min) / (window_max - window_min) * 255
            else:
                windowed = np.zeros_like(windowed)
            
            return windowed.astype(np.uint8)
            
        except Exception as e:
            main_logger.error(f"Error aplicando windowing: {str(e)}")
            return image

