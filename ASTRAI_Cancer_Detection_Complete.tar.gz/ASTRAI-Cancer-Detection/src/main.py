
import os
import sys
import argparse
import torch

# Añadir el directorio raíz del proyecto al path para importar módulos
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), 
                                                os.pardir)))

from src.core.config import Config
from src.core.logger import main_logger
from src.core.exceptions import (
    ASTRAIException, DataProcessingError, ModelLoadError,
    ModelInferenceError, TrainingError, ConfigurationError
)
from src.data.dataset import ThyroidDataset
from src.data.dicom_handler import DICOMHandler
from src.data.preprocessing import ImagePreprocessor
from src.models.cnn.thyroid_segmentation import ThyroidSegmentationModel
from src.models.llm.astrai_llm import ASTRAILLMModel
from src.core.utils import get_device

def setup_environment():
    """
    Configura el entorno de la aplicación, incluyendo directorios y logger.
    """
    main_logger.info("Configurando el entorno de ASTRAI Cancer Detection...")
    Config.create_dirs()
    main_logger.info("Directorios creados/verificados.")
    main_logger.info(f"Nivel de logging configurado a: {Config.LOG_LEVEL}")
    main_logger.info(f"Logs guardados en: {Config.LOG_FILE}")

def run_data_processing_demo(data_path: str):
    """
    Demuestra el procesamiento de datos y manejo de errores.
    """
    main_logger.info(f"Iniciando demostración de procesamiento de datos con: {data_path}")
    try:
        # Simular un directorio de datos para la demostración
        if not os.path.exists(data_path):
            main_logger.warning(f"Directorio de datos de demostración no encontrado: {data_path}. Creando uno dummy.")
            os.makedirs(data_path, exist_ok=True)
            # Crear un archivo de imagen dummy para que el dataset no esté vacío
            dummy_img_path = os.path.join(data_path, 



                                                "dummy_image.png")
            import cv2
            import numpy as np
            cv2.imwrite(dummy_img_path, np.zeros((100, 100, 3), dtype=np.uint8))

        dataset = ThyroidDataset(data_dir=data_path)
        main_logger.info(f"Dataset cargado con {len(dataset)} muestras.")

        # Procesar la primera muestra
        if len(dataset) > 0:
            image, target = dataset[0]
            main_logger.info(f"Primera muestra procesada. Imagen shape: {image.shape}, Target keys: {target.keys() if target else 'None'}")
        else:
            main_logger.warning("No hay muestras en el dataset para procesar.")

    except DataProcessingError as e:
        main_logger.error(f"Error de procesamiento de datos: {e}")
    except Exception as e:
        main_logger.error(f"Error inesperado durante la demostración de datos: {e}")

def run_model_inference_demo():
    """
    Demuestra la inferencia de modelos CNN y LLM.
    """
    main_logger.info("Iniciando demostración de inferencia de modelos...")
    device = get_device()

    try:
        # Demostración CNN
        main_logger.info("Cargando modelo CNN de segmentación...")
        cnn_config = {
            "num_classes": Config.NUM_CLASSES_SEGMENTATION,
            "backbone": "resnet50",
            "pretrained": False # Para demostración, no necesitamos pesos reales
        }
        cnn_model = ThyroidSegmentationModel(**cnn_config).to(device)
        cnn_model.eval()
        main_logger.info("Modelo CNN cargado.")

        dummy_image_tensor = torch.randn(1, 3, *Config.IMAGE_SIZE).to(device)
        with torch.no_grad():
            seg_output = cnn_model(dummy_image_tensor)
            seg_mask = cnn_model.get_segmentation_mask(dummy_image_tensor)
        main_logger.info(f"Inferencia CNN completada. Salida de segmentación shape: {seg_output.shape}, Máscara shape: {seg_mask.shape}")

        # Demostración LLM
        main_logger.info("Cargando modelo LLM ASTRAI...")
        llm_config = {
            "model_name": "microsoft/DialoGPT-medium", # Modelo pequeño para demo
            "use_quantization": False,
            "use_lora": False
        }
        llm_model = ASTRAILLMModel(**llm_config)
        main_logger.info("Modelo LLM cargado.")

        dummy_findings = {
            "num_nodules": 2,
            "max_nodule_size": 15.5,
            "tirads": 4,
            "calcifications": True,
            "echogenicity": "hypoechoic"
        }
        medical_analysis = llm_model.generate_medical_analysis(dummy_findings, analysis_type="analysis")
        main_logger.info(f"Análisis médico LLM generado: {medical_analysis[:200]}...")

    except ModelLoadError as e:
        main_logger.error(f"Error al cargar modelo: {e}")
    except ModelInferenceError as e:
        main_logger.error(f"Error durante la inferencia del modelo: {e}")
    except Exception as e:
        main_logger.error(f"Error inesperado durante la demostración de modelos: {e}")

def main():
    parser = argparse.ArgumentParser(description="ASTRAI Cancer Detection Project Main Script")
    parser.add_argument("--demo", type=str, choices=["data", "models", "all"], help="Run a specific demo: data, models, or all")
    parser.add_argument("--data_path", type=str, default=Config.RAW_DATA_DIR, help="Path to data for data processing demo")

    args = parser.parse_args()

    setup_environment()

    if args.demo == "data":
        run_data_processing_demo(args.data_path)
    elif args.demo == "models":
        run_model_inference_demo()
    elif args.demo == "all":
        run_data_processing_demo(args.data_path)
        run_model_inference_demo()
    else:
        main_logger.info("No demo specified. Use --demo [data|models|all] to run a demo.")
        main_logger.info("Para ejecutar la GUI, use 'python -m src.gui.main_window'")

if __name__ == "__main__":
    main()


