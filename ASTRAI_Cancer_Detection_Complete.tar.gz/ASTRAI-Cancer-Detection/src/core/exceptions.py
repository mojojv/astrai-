"""
Excepciones personalizadas para el proyecto ASTRAI Cancer Detection.
"""

class ASTRAIException(Exception):
    """Excepción base para el proyecto ASTRAI."""
    pass

class DataProcessingError(ASTRAIException):
    """Error en el procesamiento de datos."""
    pass

class ModelLoadError(ASTRAIException):
    """Error al cargar un modelo."""
    pass

class ModelInferenceError(ASTRAIException):
    """Error durante la inferencia del modelo."""
    pass

class TrainingError(ASTRAIException):
    """Error durante el entrenamiento del modelo."""
    pass

class ConfigurationError(ASTRAIException):
    """Error en la configuración del sistema."""
    pass

class APIError(ASTRAIException):
    """Error en la API."""
    pass

class ValidationError(ASTRAIException):
    """Error de validación de datos."""
    pass

class DICOMProcessingError(DataProcessingError):
    """Error específico en el procesamiento de archivos DICOM."""
    pass

class AnnotationError(DataProcessingError):
    """Error en el procesamiento de anotaciones."""
    pass

class LLMError(ASTRAIException):
    """Error relacionado con el LLM."""
    pass

class CNNError(ASTRAIException):
    """Error relacionado con las CNN."""
    pass

class FusionError(ASTRAIException):
    """Error en la fusión multimodal."""
    pass

class ReportGenerationError(ASTRAIException):
    """Error en la generación de reportes."""
    pass

