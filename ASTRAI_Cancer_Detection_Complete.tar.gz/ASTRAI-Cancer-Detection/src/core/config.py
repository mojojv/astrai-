
import os

class Config:
    # Directorios
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_DIR = os.path.join(BASE_DIR, 'datasets')
    RAW_DATA_DIR = os.path.join(DATA_DIR, 'raw')
    PROCESSED_DATA_DIR = os.path.join(DATA_DIR, 'processed')
    TRAINING_DATA_DIR = os.path.join(DATA_DIR, 'training_data') # Directorio para datos de entrenamiento específicos
    MODELS_DIR = os.path.join(BASE_DIR, 'models')
    CHECKPOINTS_DIR = os.path.join(MODELS_DIR, 'checkpoints')
    PRODUCTION_MODELS_DIR = os.path.join(MODELS_DIR, 'production')
    LOGS_DIR = os.path.join(BASE_DIR, 'logs')
    REPORTS_DIR = os.path.join(BASE_DIR, 'reports', 'generated_reports')
    CONFIGS_DIR = os.path.join(BASE_DIR, 'configs')

    # Configuración de Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.path.join(LOGS_DIR, 'astrai_cancer.log')
    MAX_LOG_SIZE_MB = 10
    LOG_BACKUP_COUNT = 5

    # Configuración de Modelos
    CNN_MODEL_NAME = 'resnet50_thyroid'
    LLM_MODEL_NAME = 'astrai_llm_base'
    NUM_CLASSES_SEGMENTATION = 4  # Fondo, Tiroides, Nódulo, Calcificación
    NUM_CLASSES_TIRADS = 5      # TI-RADS 1-5
    IMAGE_SIZE = (512, 512)

    # Configuración de Entrenamiento
    BATCH_SIZE = 4
    LEARNING_RATE = 1e-4
    NUM_EPOCHS = 50 # Ajustar según el tiempo de entrenamiento
    TRAIN_TIME_SECONDS = 3600 # 1 hora para pruebas, ajustar para entrenamiento real
    CHECKPOINT_INTERVAL_SECONDS = 600 # Guardar cada 10 minutos

    # Configuración de API
    API_HOST = os.getenv('API_HOST', '0.0.0.0')
    API_PORT = int(os.getenv('API_PORT', 8000))
    API_VERSION = 'v1'

    # Configuración de GUI
    GUI_DEFAULT_IMAGE_SIZE = (550, 400)

    # Crear directorios si no existen
    @staticmethod
    def create_dirs():
        for path in [Config.DATA_DIR, Config.RAW_DATA_DIR, Config.PROCESSED_DATA_DIR, 
                     Config.TRAINING_DATA_DIR, Config.MODELS_DIR, Config.CHECKPOINTS_DIR, 
                     Config.PRODUCTION_MODELS_DIR, Config.LOGS_DIR, Config.REPORTS_DIR, 
                     Config.CONFIGS_DIR]:
            os.makedirs(path, exist_ok=True)

# Inicializar directorios al importar la configuración
Config.create_dirs()


