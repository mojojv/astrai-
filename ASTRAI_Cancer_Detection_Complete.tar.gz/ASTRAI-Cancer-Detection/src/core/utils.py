"""
Utilidades generales para el proyecto ASTRAI Cancer Detection.
"""

import os
import json
import hashlib
import time
from typing import Dict, Any, Optional, Union, List
import numpy as np
import torch
from .logger import main_logger
from .exceptions import ValidationError, ConfigurationError

def generate_hash(data: Union[str, bytes]) -> str:
    """
    Genera un hash MD5 de los datos proporcionados.
    
    Args:
        data: Datos para generar el hash
        
    Returns:
        Hash MD5 como string hexadecimal
    """
    if isinstance(data, str):
        data = data.encode('utf-8')
    return hashlib.md5(data).hexdigest()

def get_timestamp() -> str:
    """
    Obtiene un timestamp formateado para nombres de archivos.
    
    Returns:
        Timestamp en formato YYYYMMDD_HHMMSS
    """
    return time.strftime('%Y%m%d_%H%M%S')

def save_json(data: Dict[Any, Any], filepath: str) -> None:
    """
    Guarda datos en formato JSON.
    
    Args:
        data: Datos a guardar
        filepath: Ruta del archivo
    """
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        main_logger.info(f"Datos guardados en {filepath}")
    except Exception as e:
        main_logger.error(f"Error guardando JSON en {filepath}: {str(e)}")
        raise

def load_json(filepath: str) -> Dict[Any, Any]:
    """
    Carga datos desde un archivo JSON.
    
    Args:
        filepath: Ruta del archivo
        
    Returns:
        Datos cargados
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        main_logger.info(f"Datos cargados desde {filepath}")
        return data
    except FileNotFoundError:
        main_logger.error(f"Archivo no encontrado: {filepath}")
        raise
    except json.JSONDecodeError as e:
        main_logger.error(f"Error decodificando JSON en {filepath}: {str(e)}")
        raise ValidationError(f"JSON inválido en {filepath}: {str(e)}")

def validate_image_path(image_path: str) -> bool:
    """
    Valida que una ruta de imagen sea válida.
    
    Args:
        image_path: Ruta de la imagen
        
    Returns:
        True si es válida, False en caso contrario
    """
    if not os.path.exists(image_path):
        return False
    
    valid_extensions = {'.png', '.jpg', '.jpeg', '.dcm', '.dicom'}
    _, ext = os.path.splitext(image_path.lower())
    return ext in valid_extensions

def get_device() -> torch.device:
    """
    Obtiene el dispositivo disponible para PyTorch.
    
    Returns:
        Dispositivo PyTorch (cuda o cpu)
    """
    if torch.cuda.is_available():
        device = torch.device('cuda')
        main_logger.info(f"Usando GPU: {torch.cuda.get_device_name()}")
    else:
        device = torch.device('cpu')
        main_logger.info("Usando CPU")
    return device

def format_bytes(bytes_value: int) -> str:
    """
    Formatea bytes en unidades legibles.
    
    Args:
        bytes_value: Valor en bytes
        
    Returns:
        String formateado (ej. "1.5 GB")
    """
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_value < 1024.0:
            return f"{bytes_value:.1f} {unit}"
        bytes_value /= 1024.0
    return f"{bytes_value:.1f} PB"

def format_time(seconds: float) -> str:
    """
    Formatea segundos en formato legible.
    
    Args:
        seconds: Tiempo en segundos
        
    Returns:
        String formateado (ej. "1h 30m 45s")
    """
    hours, remainder = divmod(int(seconds), 3600)
    minutes, seconds = divmod(remainder, 60)
    
    if hours > 0:
        return f"{hours}h {minutes}m {seconds}s"
    elif minutes > 0:
        return f"{minutes}m {seconds}s"
    else:
        return f"{seconds}s"

def ensure_dir_exists(directory: str) -> None:
    """
    Asegura que un directorio exista, creándolo si es necesario.
    
    Args:
        directory: Ruta del directorio
    """
    os.makedirs(directory, exist_ok=True)

def calculate_tirads_risk(tirads_score: int) -> str:
    """
    Calcula el nivel de riesgo basado en el score TI-RADS.
    
    Args:
        tirads_score: Score TI-RADS (1-5)
        
    Returns:
        Nivel de riesgo ('Bajo', 'Moderado', 'Alto')
    """
    if tirads_score <= 2:
        return 'Bajo'
    elif tirads_score == 3:
        return 'Moderado'
    else:
        return 'Alto'

def validate_config(config: Dict[str, Any], required_keys: List[str]) -> None:
    """
    Valida que una configuración contenga las claves requeridas.
    
    Args:
        config: Diccionario de configuración
        required_keys: Lista de claves requeridas
        
    Raises:
        ConfigurationError: Si faltan claves requeridas
    """
    missing_keys = [key for key in required_keys if key not in config]
    if missing_keys:
        raise ConfigurationError(f"Faltan claves de configuración: {missing_keys}")

def normalize_image_array(image: np.ndarray) -> np.ndarray:
    """
    Normaliza un array de imagen al rango [0, 1].
    
    Args:
        image: Array de imagen
        
    Returns:
        Array normalizado
    """
    if image.max() > 1.0:
        return image.astype(np.float32) / 255.0
    return image.astype(np.float32)

