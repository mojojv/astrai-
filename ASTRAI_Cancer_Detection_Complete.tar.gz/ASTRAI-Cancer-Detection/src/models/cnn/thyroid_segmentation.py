"""
Modelo de segmentación tiroidea para el proyecto ASTRAI Cancer Detection.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from typing import Dict, Any, Optional

from ...core.logger import main_logger
from ...core.exceptions import ModelLoadError, CNNError

class ThyroidSegmentationModel(nn.Module):
    """
    Modelo de segmentación semántica para imágenes tiroideas.
    
    Arquitectura basada en U-Net con backbone ResNet50 preentrenado.
    Clases de segmentación:
    - 0: Fondo
    - 1: Glándula tiroides
    - 2: Nódulos
    - 3: Calcificaciones
    """
    
    def __init__(self, num_classes: int = 4, backbone: str = 'resnet50', pretrained: bool = True):
        """
        Inicializa el modelo de segmentación.
        
        Args:
            num_classes: Número de clases de segmentación
            backbone: Arquitectura del backbone ('resnet50', 'resnet101')
            pretrained: Si usar pesos preentrenados
        """
        super(ThyroidSegmentationModel, self).__init__()
        
        self.num_classes = num_classes
        self.backbone_name = backbone
        
        # Cargar backbone preentrenado
        if backbone == 'resnet50':
            self.backbone = models.resnet50(pretrained=pretrained)
        elif backbone == 'resnet101':
            self.backbone = models.resnet101(pretrained=pretrained)
        else:
            raise CNNError(f"Backbone no soportado: {backbone}")
        
        # Remover las capas finales del backbone
        self.backbone = nn.Sequential(*list(self.backbone.children())[:-2])
        
        # Obtener número de características del backbone
        if backbone in ['resnet50', 'resnet101']:
            backbone_features = 2048
        else:
            backbone_features = 512
        
        # Decoder U-Net
        self.decoder = UNetDecoder(backbone_features, num_classes)
        
        # Congelar capas iniciales del backbone para transfer learning
        self._freeze_backbone_layers()
        
        main_logger.info(f"Modelo de segmentación inicializado: {backbone}, {num_classes} clases")
    
    def _freeze_backbone_layers(self, freeze_layers: int = 6):
        """
        Congela las primeras capas del backbone para transfer learning.
        
        Args:
            freeze_layers: Número de capas a congelar
        """
        for i, child in enumerate(self.backbone.children()):
            if i < freeze_layers:
                for param in child.parameters():
                    param.requires_grad = False
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass del modelo.
        
        Args:
            x: Tensor de entrada (B, C, H, W)
            
        Returns:
            Tensor de segmentación (B, num_classes, H, W)
        """
        # Extraer características con el backbone
        features = self.backbone(x)
        
        # Decodificar para obtener máscara de segmentación
        segmentation = self.decoder(features)
        
        # Redimensionar a tamaño original si es necesario
        if segmentation.shape[-2:] != x.shape[-2:]:
            segmentation = F.interpolate(
                segmentation, 
                size=x.shape[-2:], 
                mode='bilinear', 
                align_corners=True
            )
        
        return segmentation
    
    def predict(self, x: torch.Tensor, apply_softmax: bool = True) -> torch.Tensor:
        """
        Realiza predicción con el modelo.
        
        Args:
            x: Tensor de entrada
            apply_softmax: Si aplicar softmax a la salida
            
        Returns:
            Predicciones del modelo
        """
        self.eval()
        with torch.no_grad():
            logits = self.forward(x)
            
            if apply_softmax:
                predictions = F.softmax(logits, dim=1)
            else:
                predictions = logits
            
        return predictions
    
    def get_segmentation_mask(self, x: torch.Tensor) -> torch.Tensor:
        """
        Obtiene la máscara de segmentación (clase con mayor probabilidad).
        
        Args:
            x: Tensor de entrada
            
        Returns:
            Máscara de segmentación (B, H, W)
        """
        predictions = self.predict(x, apply_softmax=True)
        mask = torch.argmax(predictions, dim=1)
        return mask

class UNetDecoder(nn.Module):
    """
    Decoder U-Net para segmentación semántica.
    """
    
    def __init__(self, input_channels: int, num_classes: int):
        """
        Inicializa el decoder.
        
        Args:
            input_channels: Número de canales de entrada
            num_classes: Número de clases de salida
        """
        super(UNetDecoder, self).__init__()
        
        # Capas de upsampling y convolución
        self.up1 = self._make_up_block(input_channels, 512)
        self.up2 = self._make_up_block(512, 256)
        self.up3 = self._make_up_block(256, 128)
        self.up4 = self._make_up_block(128, 64)
        
        # Capa final de clasificación
        self.final_conv = nn.Conv2d(64, num_classes, kernel_size=1)
        
    def _make_up_block(self, in_channels: int, out_channels: int) -> nn.Module:
        """
        Crea un bloque de upsampling.
        
        Args:
            in_channels: Canales de entrada
            out_channels: Canales de salida
            
        Returns:
            Bloque de upsampling
        """
        return nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass del decoder.
        
        Args:
            x: Características del encoder
            
        Returns:
            Mapa de segmentación
        """
        x = self.up1(x)
        x = self.up2(x)
        x = self.up3(x)
        x = self.up4(x)
        x = self.final_conv(x)
        
        return x

class SegmentationLoss(nn.Module):
    """
    Función de pérdida combinada para segmentación.
    Combina Cross Entropy Loss y Dice Loss.
    """
    
    def __init__(self, num_classes: int, class_weights: Optional[torch.Tensor] = None, dice_weight: float = 0.5):
        """
        Inicializa la función de pérdida.
        
        Args:
            num_classes: Número de clases
            class_weights: Pesos para balancear clases
            dice_weight: Peso para Dice Loss (0-1)
        """
        super(SegmentationLoss, self).__init__()
        
        self.num_classes = num_classes
        self.dice_weight = dice_weight
        self.ce_weight = 1.0 - dice_weight
        
        # Cross Entropy Loss
        self.ce_loss = nn.CrossEntropyLoss(weight=class_weights)
        
    def forward(self, predictions: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Calcula la pérdida combinada.
        
        Args:
            predictions: Predicciones del modelo (B, C, H, W)
            targets: Targets verdaderos (B, H, W)
            
        Returns:
            Pérdida total
        """
        # Cross Entropy Loss
        ce_loss = self.ce_loss(predictions, targets)
        
        # Dice Loss
        dice_loss = self._dice_loss(predictions, targets)
        
        # Pérdida combinada
        total_loss = self.ce_weight * ce_loss + self.dice_weight * dice_loss
        
        return total_loss
    
    def _dice_loss(self, predictions: torch.Tensor, targets: torch.Tensor, smooth: float = 1e-6) -> torch.Tensor:
        """
        Calcula Dice Loss.
        
        Args:
            predictions: Predicciones del modelo
            targets: Targets verdaderos
            smooth: Factor de suavizado
            
        Returns:
            Dice Loss
        """
        # Aplicar softmax a las predicciones
        predictions = F.softmax(predictions, dim=1)
        
        # Convertir targets a one-hot encoding
        targets_one_hot = F.one_hot(targets, num_classes=self.num_classes)
        targets_one_hot = targets_one_hot.permute(0, 3, 1, 2).float()
        
        # Calcular Dice coefficient para cada clase
        dice_scores = []
        for class_idx in range(self.num_classes):
            pred_class = predictions[:, class_idx]
            target_class = targets_one_hot[:, class_idx]
            
            intersection = (pred_class * target_class).sum(dim=(1, 2))
            union = pred_class.sum(dim=(1, 2)) + target_class.sum(dim=(1, 2))
            
            dice = (2.0 * intersection + smooth) / (union + smooth)
            dice_scores.append(dice)
        
        # Promedio de Dice scores
        dice_score = torch.stack(dice_scores, dim=1).mean()
        
        # Dice Loss = 1 - Dice Score
        dice_loss = 1.0 - dice_score
        
        return dice_loss

def create_segmentation_model(config: Dict[str, Any]) -> ThyroidSegmentationModel:
    """
    Factory function para crear modelo de segmentación.
    
    Args:
        config: Configuración del modelo
        
    Returns:
        Modelo de segmentación inicializado
    """
    try:
        model = ThyroidSegmentationModel(
            num_classes=config.get('num_classes', 4),
            backbone=config.get('backbone', 'resnet50'),
            pretrained=config.get('pretrained', True)
        )
        
        main_logger.info("Modelo de segmentación creado exitosamente")
        return model
        
    except Exception as e:
        raise ModelLoadError(f"Error creando modelo de segmentación: {str(e)}")

def load_segmentation_model(model_path: str, config: Dict[str, Any]) -> ThyroidSegmentationModel:
    """
    Carga un modelo de segmentación desde archivo.
    
    Args:
        model_path: Ruta del modelo guardado
        config: Configuración del modelo
        
    Returns:
        Modelo cargado
    """
    try:
        model = create_segmentation_model(config)
        
        # Cargar pesos del modelo
        checkpoint = torch.load(model_path, map_location='cpu')
        
        if 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        else:
            model.load_state_dict(checkpoint)
        
        main_logger.info(f"Modelo de segmentación cargado desde: {model_path}")
        return model
        
    except Exception as e:
        raise ModelLoadError(f"Error cargando modelo de segmentación: {str(e)}")

