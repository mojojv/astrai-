"""
Modelo LLM ASTRAI para análisis médico y generación de reportes.
"""

import torch
import torch.nn as nn
from transformers import (
    AutoTokenizer, AutoModelForCausalLM, AutoConfig,
    BitsAndBytesConfig, TrainingArguments, Trainer
)
from peft import LoraConfig, get_peft_model, TaskType
from typing import Dict, List, Any, Optional, Tuple
import json
import os

from ...core.logger import main_logger
from ...core.exceptions import LLMError, ModelLoadError
from ...core.config import Config

class ASTRAILLMModel:
    """
    Modelo LLM especializado para análisis médico tiroideo.
    
    Basado en modelos de lenguaje grandes con fine-tuning específico
    para terminología médica y análisis de imágenes tiroideas.
    """
    
    def __init__(
        self,
        model_name: str = "microsoft/DialoGPT-medium",
        use_quantization: bool = True,
        use_lora: bool = True,
        device: str = "auto"
    ):
        """
        Inicializa el modelo LLM ASTRAI.
        
        Args:
            model_name: Nombre del modelo base de Hugging Face
            use_quantization: Si usar cuantización para reducir memoria
            use_lora: Si usar LoRA para fine-tuning eficiente
            device: Dispositivo a usar ('auto', 'cuda', 'cpu')
        """
        self.model_name = model_name
        self.use_quantization = use_quantization
        self.use_lora = use_lora
        
        # Configurar dispositivo
        if device == "auto":
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device
        
        # Inicializar componentes
        self.tokenizer = None
        self.model = None
        self.config = None
        
        # Cargar modelo
        self._load_model()
        
        # Configurar prompts especializados
        self._setup_medical_prompts()
        
        main_logger.info(f"Modelo ASTRAI LLM inicializado: {model_name} en {self.device}")
    
    def _load_model(self):
        """Carga el modelo y tokenizer."""
        try:
            # Configurar cuantización si está habilitada
            quantization_config = None
            if self.use_quantization and self.device == "cuda":
                quantization_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.float16,
                    bnb_4bit_use_double_quant=True,
                    bnb_4bit_quant_type="nf4"
                )
            
            # Cargar configuración
            self.config = AutoConfig.from_pretrained(self.model_name)
            
            # Cargar tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                self.model_name,
                padding_side="left",
                trust_remote_code=True
            )
            
            # Agregar token de padding si no existe
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token
            
            # Cargar modelo
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_name,
                config=self.config,
                quantization_config=quantization_config,
                device_map="auto" if self.device == "cuda" else None,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                trust_remote_code=True
            )
            
            # Configurar LoRA si está habilitado
            if self.use_lora:
                self._setup_lora()
            
        except Exception as e:
            raise ModelLoadError(f"Error cargando modelo LLM: {str(e)}")
    
    def _setup_lora(self):
        """Configura LoRA para fine-tuning eficiente."""
        try:
            lora_config = LoraConfig(
                task_type=TaskType.CAUSAL_LM,
                inference_mode=False,
                r=16,
                lora_alpha=32,
                lora_dropout=0.1,
                target_modules=["q_proj", "v_proj", "k_proj", "o_proj"]
            )
            
            self.model = get_peft_model(self.model, lora_config)
            main_logger.info("LoRA configurado para fine-tuning eficiente")
            
        except Exception as e:
            main_logger.warning(f"Error configurando LoRA: {str(e)}")
    
    def _setup_medical_prompts(self):
        """Configura prompts especializados para análisis médico."""
        self.medical_prompts = {
            "analysis": """Como especialista en radiología tiroidea, analiza los siguientes hallazgos de imagen:

Hallazgos detectados:
{findings}

Proporciona un análisis detallado que incluya:
1. Interpretación de los hallazgos
2. Clasificación TI-RADS
3. Nivel de riesgo
4. Recomendaciones clínicas

Análisis:""",
            
            "report_generation": """Genera un reporte médico profesional basado en los siguientes datos:

Datos del paciente: {patient_data}
Hallazgos de imagen: {image_findings}
Análisis automatizado: {automated_analysis}

El reporte debe incluir:
- Técnica de examen
- Hallazgos principales
- Impresión diagnóstica
- Recomendaciones

REPORTE MÉDICO:""",
            
            "risk_assessment": """Evalúa el riesgo de malignidad basado en los siguientes criterios TI-RADS:

Características del nódulo:
{nodule_characteristics}

Proporciona:
1. Puntuación TI-RADS detallada
2. Porcentaje de riesgo de malignidad
3. Recomendaciones de seguimiento

Evaluación de riesgo:""",
            
            "differential_diagnosis": """Proporciona un diagnóstico diferencial para los siguientes hallazgos tiroideos:

Hallazgos clínicos: {clinical_findings}
Hallazgos de imagen: {imaging_findings}

Lista los posibles diagnósticos en orden de probabilidad con justificación:

Diagnóstico diferencial:"""
        }
    
    def generate_medical_analysis(
        self,
        findings: Dict[str, Any],
        analysis_type: str = "analysis",
        max_length: int = 512,
        temperature: float = 0.7
    ) -> str:
        """
        Genera análisis médico basado en hallazgos.
        
        Args:
            findings: Diccionario con hallazgos médicos
            analysis_type: Tipo de análisis ('analysis', 'report_generation', etc.)
            max_length: Longitud máxima de la respuesta
            temperature: Temperatura para generación
            
        Returns:
            Texto del análisis generado
        """
        try:
            # Seleccionar prompt apropiado
            if analysis_type not in self.medical_prompts:
                raise LLMError(f"Tipo de análisis no soportado: {analysis_type}")
            
            prompt_template = self.medical_prompts[analysis_type]
            
            # Formatear prompt con hallazgos
            if analysis_type == "analysis":
                prompt = prompt_template.format(findings=self._format_findings(findings))
            elif analysis_type == "report_generation":
                prompt = prompt_template.format(
                    patient_data=findings.get('patient_data', 'No disponible'),
                    image_findings=self._format_findings(findings.get('image_findings', {})),
                    automated_analysis=findings.get('automated_analysis', 'No disponible')
                )
            elif analysis_type == "risk_assessment":
                prompt = prompt_template.format(
                    nodule_characteristics=self._format_nodule_characteristics(findings)
                )
            elif analysis_type == "differential_diagnosis":
                prompt = prompt_template.format(
                    clinical_findings=findings.get('clinical_findings', 'No disponible'),
                    imaging_findings=self._format_findings(findings.get('imaging_findings', {}))
                )
            else:
                prompt = prompt_template.format(**findings)
            
            # Generar respuesta
            response = self._generate_text(prompt, max_length, temperature)
            
            return response
            
        except Exception as e:
            raise LLMError(f"Error generando análisis médico: {str(e)}")
    
    def _format_findings(self, findings: Dict[str, Any]) -> str:
        """Formatea hallazgos para el prompt."""
        formatted = []
        
        for key, value in findings.items():
            if isinstance(value, (list, tuple)):
                formatted.append(f"- {key}: {', '.join(map(str, value))}")
            elif isinstance(value, dict):
                formatted.append(f"- {key}:")
                for subkey, subvalue in value.items():
                    formatted.append(f"  * {subkey}: {subvalue}")
            else:
                formatted.append(f"- {key}: {value}")
        
        return "\n".join(formatted)
    
    def _format_nodule_characteristics(self, findings: Dict[str, Any]) -> str:
        """Formatea características de nódulos para evaluación TI-RADS."""
        characteristics = []
        
        # Características principales para TI-RADS
        tirads_features = [
            'composition', 'echogenicity', 'shape', 'margin', 'echogenic_foci'
        ]
        
        for feature in tirads_features:
            if feature in findings:
                characteristics.append(f"- {feature.replace('_', ' ').title()}: {findings[feature]}")
        
        # Agregar otras características relevantes
        for key, value in findings.items():
            if key not in tirads_features:
                characteristics.append(f"- {key.replace('_', ' ').title()}: {value}")
        
        return "\n".join(characteristics)
    
    def _generate_text(
        self,
        prompt: str,
        max_length: int = 512,
        temperature: float = 0.7,
        do_sample: bool = True,
        top_p: float = 0.9
    ) -> str:
        """
        Genera texto usando el modelo LLM.
        
        Args:
            prompt: Prompt de entrada
            max_length: Longitud máxima
            temperature: Temperatura de generación
            do_sample: Si usar sampling
            top_p: Parámetro top-p para nucleus sampling
            
        Returns:
            Texto generado
        """
        try:
            # Tokenizar prompt
            inputs = self.tokenizer.encode(prompt, return_tensors="pt")
            inputs = inputs.to(self.device)
            
            # Configurar parámetros de generación
            generation_config = {
                "max_length": len(inputs[0]) + max_length,
                "temperature": temperature,
                "do_sample": do_sample,
                "top_p": top_p,
                "pad_token_id": self.tokenizer.pad_token_id,
                "eos_token_id": self.tokenizer.eos_token_id,
                "repetition_penalty": 1.1,
                "length_penalty": 1.0
            }
            
            # Generar texto
            with torch.no_grad():
                outputs = self.model.generate(inputs, **generation_config)
            
            # Decodificar respuesta
            generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            # Extraer solo la parte generada (después del prompt)
            response = generated_text[len(prompt):].strip()
            
            return response
            
        except Exception as e:
            raise LLMError(f"Error generando texto: {str(e)}")
    
    def fine_tune(
        self,
        training_data: List[Dict[str, str]],
        output_dir: str,
        num_epochs: int = 3,
        learning_rate: float = 2e-4,
        batch_size: int = 4
    ):
        """
        Fine-tune el modelo con datos médicos específicos.
        
        Args:
            training_data: Lista de ejemplos de entrenamiento
            output_dir: Directorio para guardar el modelo fine-tuned
            num_epochs: Número de épocas
            learning_rate: Tasa de aprendizaje
            batch_size: Tamaño de batch
        """
        try:
            # Preparar datos de entrenamiento
            train_dataset = self._prepare_training_data(training_data)
            
            # Configurar argumentos de entrenamiento
            training_args = TrainingArguments(
                output_dir=output_dir,
                num_train_epochs=num_epochs,
                per_device_train_batch_size=batch_size,
                gradient_accumulation_steps=2,
                warmup_steps=100,
                learning_rate=learning_rate,
                fp16=True if self.device == "cuda" else False,
                logging_steps=10,
                save_steps=500,
                evaluation_strategy="no",
                save_strategy="steps",
                load_best_model_at_end=False,
                report_to=None
            )
            
            # Crear trainer
            trainer = Trainer(
                model=self.model,
                args=training_args,
                train_dataset=train_dataset,
                tokenizer=self.tokenizer,
                data_collator=self._data_collator
            )
            
            # Entrenar modelo
            trainer.train()
            
            # Guardar modelo fine-tuned
            trainer.save_model()
            self.tokenizer.save_pretrained(output_dir)
            
            main_logger.info(f"Fine-tuning completado. Modelo guardado en: {output_dir}")
            
        except Exception as e:
            raise LLMError(f"Error en fine-tuning: {str(e)}")
    
    def _prepare_training_data(self, training_data: List[Dict[str, str]]):
        """Prepara datos para entrenamiento."""
        # Implementar preparación de datos específica
        # Esta es una implementación simplificada
        texts = []
        for example in training_data:
            if 'input' in example and 'output' in example:
                text = f"{example['input']}\n{example['output']}"
                texts.append(text)
        
        # Tokenizar textos
        tokenized = self.tokenizer(
            texts,
            truncation=True,
            padding=True,
            max_length=512,
            return_tensors="pt"
        )
        
        return tokenized
    
    def _data_collator(self, batch):
        """Collator personalizado para datos de entrenamiento."""
        # Implementación simplificada
        return self.tokenizer.pad(batch, return_tensors="pt")
    
    def save_model(self, save_path: str):
        """
        Guarda el modelo entrenado.
        
        Args:
            save_path: Ruta donde guardar el modelo
        """
        try:
            os.makedirs(save_path, exist_ok=True)
            
            # Guardar modelo y tokenizer
            self.model.save_pretrained(save_path)
            self.tokenizer.save_pretrained(save_path)
            
            # Guardar configuración adicional
            config_data = {
                'model_name': self.model_name,
                'use_quantization': self.use_quantization,
                'use_lora': self.use_lora,
                'device': self.device
            }
            
            with open(os.path.join(save_path, 'astrai_config.json'), 'w') as f:
                json.dump(config_data, f, indent=2)
            
            main_logger.info(f"Modelo ASTRAI guardado en: {save_path}")
            
        except Exception as e:
            raise LLMError(f"Error guardando modelo: {str(e)}")
    
    @classmethod
    def load_model(cls, model_path: str):
        """
        Carga un modelo ASTRAI previamente guardado.
        
        Args:
            model_path: Ruta del modelo guardado
            
        Returns:
            Instancia del modelo cargado
        """
        try:
            # Cargar configuración
            config_path = os.path.join(model_path, 'astrai_config.json')
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    config = json.load(f)
            else:
                config = {}
            
            # Crear instancia con configuración guardada
            instance = cls(
                model_name=model_path,  # Usar ruta local como model_name
                use_quantization=config.get('use_quantization', True),
                use_lora=config.get('use_lora', True),
                device=config.get('device', 'auto')
            )
            
            main_logger.info(f"Modelo ASTRAI cargado desde: {model_path}")
            return instance
            
        except Exception as e:
            raise ModelLoadError(f"Error cargando modelo ASTRAI: {str(e)}")

def create_astrai_llm(config: Dict[str, Any]) -> ASTRAILLMModel:
    """
    Factory function para crear modelo ASTRAI LLM.
    
    Args:
        config: Configuración del modelo
        
    Returns:
        Modelo ASTRAI LLM inicializado
    """
    try:
        model = ASTRAILLMModel(
            model_name=config.get('model_name', 'microsoft/DialoGPT-medium'),
            use_quantization=config.get('use_quantization', True),
            use_lora=config.get('use_lora', True),
            device=config.get('device', 'auto')
        )
        
        main_logger.info("Modelo ASTRAI LLM creado exitosamente")
        return model
        
    except Exception as e:
        raise ModelLoadError(f"Error creando modelo ASTRAI LLM: {str(e)}")

