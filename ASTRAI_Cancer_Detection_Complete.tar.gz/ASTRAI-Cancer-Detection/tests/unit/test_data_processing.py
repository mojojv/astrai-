
import unittest
import os
import numpy as np
import cv2
import json
from unittest.mock import patch, MagicMock

from src.data.dataset import ThyroidDataset
from src.data.dicom_handler import DICOMHandler
from src.data.preprocessing import ImagePreprocessor
from src.core.exceptions import DataProcessingError, DICOMProcessingError, AnnotationError

class TestDataProcessing(unittest.TestCase):

    def setUp(self):
        self.test_data_dir = "./test_data"
        os.makedirs(self.test_data_dir, exist_ok=True)
        
        # Crear una imagen de prueba (PNG)
        self.test_png_path = os.path.join(self.test_data_dir, "test_image.png")
        dummy_image = np.zeros((100, 100, 3), dtype=np.uint8)
        cv2.imwrite(self.test_png_path, dummy_image)
        
        # Crear una anotación de prueba (JSON)
        self.test_json_path = os.path.join(self.test_data_dir, "test_image.json")
        dummy_annotation = {
            "thyroid": {"position": [50, 50], "width": 40, "height": 30},
            "nodules": [
                {"bbox": [10, 10, 20, 20]},
                {"bbox": [70, 70, 80, 80]}
            ],
            "calcifications": [
                {"position": [30, 30], "size": 5}
            ],
            "tirads": 3
        }
        with open(self.test_json_path, "w") as f:
            json.dump(dummy_annotation, f)
            
        # Crear un archivo DICOM de prueba (simulado)
        self.test_dcm_path = os.path.join(self.test_data_dir, "test_dicom.dcm")
        with open(self.test_dcm_path, "w") as f:
            f.write("dummy dicom content")

    def tearDown(self):
        # Limpiar archivos de prueba
        os.remove(self.test_png_path)
        os.remove(self.test_json_path)
        os.remove(self.test_dcm_path)
        os.rmdir(self.test_data_dir)

    @patch("src.data.dicom_handler.pydicom.dcmread")
    def test_dicom_handler_load_dicom_image(self, mock_dcmread):
        # Mockear pydicom para simular un archivo DICOM
        mock_dicom_data = MagicMock()
        mock_dicom_data.pixel_array = np.zeros((100, 100), dtype=np.uint16)
        mock_dicom_data.WindowCenter = 1000
        mock_dicom_data.WindowWidth = 2000
        mock_dcmread.return_value = mock_dicom_data

        handler = DICOMHandler()
        image = handler.load_dicom_image(self.test_dcm_path)
        self.assertIsInstance(image, np.ndarray)
        self.assertEqual(image.shape, (100, 100, 3))
        mock_dcmread.assert_called_once_with(self.test_dcm_path)

    @patch("src.data.dicom_handler.pydicom.dcmread")
    def test_dicom_handler_load_dicom_image_error(self, mock_dcmread):
        mock_dcmread.side_effect = Exception("Invalid DICOM")
        handler = DICOMHandler()
        with self.assertRaises(DICOMProcessingError):
            handler.load_dicom_image(self.test_dcm_path)

    def test_image_preprocessor_enhance_image(self):
        preprocessor = ImagePreprocessor()
        dummy_image = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        enhanced_image = preprocessor.enhance_image(dummy_image)
        self.assertIsInstance(enhanced_image, np.ndarray)
        self.assertEqual(enhanced_image.shape, (100, 100, 3))

    def test_thyroid_dataset_load_data(self):
        dataset = ThyroidDataset(self.test_data_dir)
        self.assertEqual(len(dataset), 1)
        self.assertEqual(dataset.image_paths[0], self.test_png_path)
        self.assertIsNotNone(dataset.annotations[0])

    def test_thyroid_dataset_getitem(self):
        dataset = ThyroidDataset(self.test_data_dir)
        image, target = dataset[0]
        self.assertIsInstance(image, torch.Tensor)
        self.assertIsInstance(target, dict)
        self.assertIn("seg_mask", target)
        self.assertIn("tirads", target)
        self.assertEqual(target["tirads"].item(), 2) # TI-RADS 3 -> index 2

    def test_thyroid_dataset_getitem_error_handling(self):
        # Crear un archivo de imagen corrupto
        corrupt_path = os.path.join(self.test_data_dir, "corrupt.png")
        with open(corrupt_path, "w") as f:
            f.write("corrupt data")
        
        # Añadir la imagen corrupta al dataset
        dataset = ThyroidDataset(self.test_data_dir)
        dataset.image_paths.append(corrupt_path)
        dataset.annotations.append(None) # No hay anotación para la corrupta

        # Intentar cargar la imagen corrupta
        image, target = dataset[len(dataset) - 1]
        self.assertIsInstance(image, torch.Tensor)
        self.assertIsNone(target) # Target debe ser None en caso de error
        self.assertEqual(image.shape, (3, 512, 512)) # Debe retornar un tensor vacío

if __name__ == '__main__':
    unittest.main()


