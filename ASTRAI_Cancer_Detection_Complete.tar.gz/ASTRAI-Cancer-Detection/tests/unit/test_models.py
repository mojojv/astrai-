import unittest
import torch
import torch.nn as nn
import numpy as np
from unittest.mock import patch, MagicMock

from src.models.cnn.thyroid_segmentation import ThyroidSegmentationModel, SegmentationLoss
from src.models.llm.astrai_llm import ASTRAILLMModel
from src.core.exceptions import ModelLoadError, CNNError, LLMError

class TestCNNModels(unittest.TestCase):

    def test_thyroid_segmentation_model_init(self):
        model = ThyroidSegmentationModel(num_classes=4, backbone='resnet50')
        self.assertIsInstance(model, nn.Module)
        self.assertEqual(model.num_classes, 4)
        self.assertEqual(model.backbone_name, 'resnet50')

    def test_thyroid_segmentation_model_forward(self):
        model = ThyroidSegmentationModel(num_classes=4)
        dummy_input = torch.randn(2, 3, 512, 512)
        output = model(dummy_input)
        self.assertEqual(output.shape, (2, 4, 512, 512))

    def test_thyroid_segmentation_model_predict(self):
        model = ThyroidSegmentationModel(num_classes=4)
        dummy_input = torch.randn(1, 3, 512, 512)
        predictions = model.predict(dummy_input)
        self.assertEqual(predictions.shape, (1, 4, 512, 512))
        # Verificar que las probabilidades suman 1 (softmax)
        prob_sum = predictions.sum(dim=1)
        self.assertTrue(torch.allclose(prob_sum, torch.ones_like(prob_sum), atol=1e-6))

    def test_thyroid_segmentation_model_get_segmentation_mask(self):
        model = ThyroidSegmentationModel(num_classes=4)
        dummy_input = torch.randn(1, 3, 512, 512)
        mask = model.get_segmentation_mask(dummy_input)
        self.assertEqual(mask.shape, (1, 512, 512))
        self.assertTrue(torch.all(mask >= 0) and torch.all(mask < 4))

    def test_segmentation_loss_forward(self):
        loss_fn = SegmentationLoss(num_classes=4)
        predictions = torch.randn(2, 4, 64, 64)
        targets = torch.randint(0, 4, (2, 64, 64))
        loss = loss_fn(predictions, targets)
        self.assertIsInstance(loss, torch.Tensor)
        self.assertEqual(loss.dim(), 0)  # Scalar loss

    def test_segmentation_loss_dice_loss(self):
        loss_fn = SegmentationLoss(num_classes=4, dice_weight=1.0)  # Solo Dice Loss
        predictions = torch.randn(1, 4, 32, 32)
        targets = torch.randint(0, 4, (1, 32, 32))
        loss = loss_fn(predictions, targets)
        self.assertIsInstance(loss, torch.Tensor)
        self.assertTrue(loss >= 0.0 and loss <= 1.0)  # Dice Loss está en [0, 1]

    def test_thyroid_segmentation_model_invalid_backbone(self):
        with self.assertRaises(CNNError):
            ThyroidSegmentationModel(backbone='invalid_backbone')

class TestLLMModels(unittest.TestCase):

    @patch('src.models.llm.astrai_llm.AutoTokenizer.from_pretrained')
    @patch('src.models.llm.astrai_llm.AutoModelForCausalLM.from_pretrained')
    @patch('src.models.llm.astrai_llm.AutoConfig.from_pretrained')
    def test_astrai_llm_model_init(self, mock_config, mock_model, mock_tokenizer):
        # Mockear componentes de Hugging Face
        mock_config.return_value = MagicMock()
        mock_tokenizer.return_value = MagicMock()
        mock_tokenizer.return_value.pad_token = None
        mock_tokenizer.return_value.eos_token = '<eos>'
        mock_model.return_value = MagicMock()

        model = ASTRAILLMModel(model_name='test_model', use_quantization=False, use_lora=False)
        self.assertIsNotNone(model.tokenizer)
        self.assertIsNotNone(model.model)
        self.assertEqual(model.model_name, 'test_model')

    @patch('src.models.llm.astrai_llm.AutoTokenizer.from_pretrained')
    @patch('src.models.llm.astrai_llm.AutoModelForCausalLM.from_pretrained')
    @patch('src.models.llm.astrai_llm.AutoConfig.from_pretrained')
    def test_astrai_llm_generate_medical_analysis(self, mock_config, mock_model, mock_tokenizer):
        # Mockear componentes
        mock_config.return_value = MagicMock()
        mock_tokenizer_instance = MagicMock()
        mock_tokenizer_instance.pad_token = '<pad>'
        mock_tokenizer_instance.eos_token = '<eos>'
        mock_tokenizer_instance.pad_token_id = 0
        mock_tokenizer_instance.eos_token_id = 1
        mock_tokenizer_instance.encode.return_value = torch.tensor([[1, 2, 3]])
        mock_tokenizer_instance.decode.return_value = "Test prompt Test analysis result"
        mock_tokenizer.return_value = mock_tokenizer_instance

        mock_model_instance = MagicMock()
        mock_model_instance.generate.return_value = torch.tensor([[1, 2, 3, 4, 5]])
        mock_model.return_value = mock_model_instance

        model = ASTRAILLMModel(model_name='test_model', use_quantization=False, use_lora=False)
        
        findings = {
            'num_nodules': 2,
            'max_nodule_size': 15.5,
            'tirads': 4,
            'calcifications': True
        }
        
        result = model.generate_medical_analysis(findings, analysis_type='analysis')
        self.assertIsInstance(result, str)
        self.assertIn("analysis result", result)

    @patch('src.models.llm.astrai_llm.AutoTokenizer.from_pretrained')
    @patch('src.models.llm.astrai_llm.AutoModelForCausalLM.from_pretrained')
    @patch('src.models.llm.astrai_llm.AutoConfig.from_pretrained')
    def test_astrai_llm_invalid_analysis_type(self, mock_config, mock_model, mock_tokenizer):
        # Mockear componentes básicos
        mock_config.return_value = MagicMock()
        mock_tokenizer.return_value = MagicMock()
        mock_tokenizer.return_value.pad_token = '<pad>'
        mock_tokenizer.return_value.eos_token = '<eos>'
        mock_model.return_value = MagicMock()

        model = ASTRAILLMModel(model_name='test_model', use_quantization=False, use_lora=False)
        
        with self.assertRaises(LLMError):
            model.generate_medical_analysis({}, analysis_type='invalid_type')

    def test_astrai_llm_format_findings(self):
        # Crear una instancia mock para probar métodos privados
        with patch('src.models.llm.astrai_llm.AutoTokenizer.from_pretrained'), \
             patch('src.models.llm.astrai_llm.AutoModelForCausalLM.from_pretrained'), \
             patch('src.models.llm.astrai_llm.AutoConfig.from_pretrained'):
            
            mock_tokenizer = MagicMock()
            mock_tokenizer.pad_token = '<pad>'
            mock_tokenizer.eos_token = '<eos>'
            
            model = ASTRAILLMModel(model_name='test_model', use_quantization=False, use_lora=False)
            
            findings = {
                'simple_value': 'test',
                'list_value': [1, 2, 3],
                'dict_value': {'sub_key': 'sub_value'}
            }
            
            formatted = model._format_findings(findings)
            self.assertIn('simple_value: test', formatted)
            self.assertIn('list_value: 1, 2, 3', formatted)
            self.assertIn('dict_value:', formatted)
            self.assertIn('sub_key: sub_value', formatted)

class TestModelIntegration(unittest.TestCase):

    def test_cnn_llm_pipeline(self):
        """Prueba la integración básica entre CNN y LLM"""
        # Crear modelo CNN
        cnn_model = ThyroidSegmentationModel(num_classes=4)
        
        # Simular entrada
        dummy_input = torch.randn(1, 3, 512, 512)
        
        # Obtener predicciones CNN
        with torch.no_grad():
            segmentation = cnn_model(dummy_input)
            mask = torch.argmax(segmentation, dim=1)
        
        # Simular extracción de características para LLM
        unique_classes, counts = torch.unique(mask, return_counts=True)
        
        # Crear hallazgos simulados para LLM
        findings = {
            'detected_classes': unique_classes.tolist(),
            'class_counts': counts.tolist(),
            'image_size': dummy_input.shape[-2:]
        }
        
        # Verificar que los hallazgos son válidos
        self.assertIsInstance(findings['detected_classes'], list)
        self.assertIsInstance(findings['class_counts'], list)
        self.assertEqual(len(findings['detected_classes']), len(findings['class_counts']))

if __name__ == '__main__':
    unittest.main()

