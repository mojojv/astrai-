import unittest
import os
import tempfile
import shutil
import torch
import numpy as np
import cv2
import json
from unittest.mock import patch, MagicMock

from src.data.dataset import ThyroidDataset
from src.models.cnn.thyroid_segmentation import ThyroidSegmentationModel
from src.models.llm.astrai_llm import ASTRAILLMModel
from src.core.config import Config
from src.core.exceptions import ASTRAIException

class TestFullPipeline(unittest.TestCase):
    """
    Pruebas de integración para el pipeline completo de ASTRAI.
    """

    def setUp(self):
        """Configurar entorno de prueba."""
        # Crear directorio temporal para pruebas
        self.test_dir = tempfile.mkdtemp()
        self.test_data_dir = os.path.join(self.test_dir, "test_data")
        os.makedirs(self.test_data_dir, exist_ok=True)
        
        # Crear datos de prueba
        self._create_test_data()
        
        # Configurar modelos de prueba
        self.cnn_model = None
        self.llm_model = None

    def tearDown(self):
        """Limpiar entorno de prueba."""
        shutil.rmtree(self.test_dir)

    def _create_test_data(self):
        """Crear datos de prueba sintéticos."""
        # Crear múltiples imágenes de prueba
        for i in range(3):
            # Imagen sintética
            image = np.random.randint(0, 255, (256, 256, 3), dtype=np.uint8)
            image_path = os.path.join(self.test_data_dir, f"test_image_{i}.png")
            cv2.imwrite(image_path, image)
            
            # Anotación correspondiente
            annotation = {
                "thyroid": {
                    "position": [128 + i*10, 128 + i*10],
                    "width": 80 + i*5,
                    "height": 60 + i*5
                },
                "nodules": [
                    {"bbox": [50 + i*10, 50 + i*10, 70 + i*10, 70 + i*10]},
                    {"bbox": [180 - i*5, 180 - i*5, 200 - i*5, 200 - i*5]}
                ],
                "calcifications": [
                    {"position": [100 + i*5, 100 + i*5], "size": 3 + i}
                ],
                "tirads": 2 + i
            }
            
            annotation_path = os.path.join(self.test_data_dir, f"test_image_{i}.json")
            with open(annotation_path, 'w') as f:
                json.dump(annotation, f)

    def test_data_loading_pipeline(self):
        """Prueba el pipeline de carga de datos."""
        # Crear dataset
        dataset = ThyroidDataset(
            data_dir=self.test_data_dir,
            target_size=(256, 256),
            max_samples=3
        )
        
        # Verificar carga correcta
        self.assertEqual(len(dataset), 3)
        
        # Probar carga de muestras
        for i in range(len(dataset)):
            image, target = dataset[i]
            
            # Verificar formato de imagen
            self.assertIsInstance(image, torch.Tensor)
            self.assertEqual(image.shape, (3, 256, 256))
            
            # Verificar target
            self.assertIsNotNone(target)
            self.assertIn('seg_mask', target)
            self.assertIn('tirads', target)
            
            # Verificar rango de valores
            self.assertTrue(torch.all(target['tirads'] >= 0))
            self.assertTrue(torch.all(target['tirads'] <= 4))

    def test_cnn_inference_pipeline(self):
        """Prueba el pipeline de inferencia CNN."""
        # Crear modelo CNN
        model = ThyroidSegmentationModel(num_classes=4, backbone='resnet50', pretrained=False)
        model.eval()
        
        # Crear entrada de prueba
        batch_size = 2
        dummy_input = torch.randn(batch_size, 3, 256, 256)
        
        # Realizar inferencia
        with torch.no_grad():
            output = model(dummy_input)
            predictions = model.predict(dummy_input)
            masks = model.get_segmentation_mask(dummy_input)
        
        # Verificar salidas
        self.assertEqual(output.shape, (batch_size, 4, 256, 256))
        self.assertEqual(predictions.shape, (batch_size, 4, 256, 256))
        self.assertEqual(masks.shape, (batch_size, 256, 256))
        
        # Verificar que las máscaras contienen clases válidas
        self.assertTrue(torch.all(masks >= 0))
        self.assertTrue(torch.all(masks < 4))

    @patch('src.models.llm.astrai_llm.AutoTokenizer.from_pretrained')
    @patch('src.models.llm.astrai_llm.AutoModelForCausalLM.from_pretrained')
    @patch('src.models.llm.astrai_llm.AutoConfig.from_pretrained')
    def test_llm_analysis_pipeline(self, mock_config, mock_model, mock_tokenizer):
        """Prueba el pipeline de análisis LLM."""
        # Mockear componentes de Hugging Face
        mock_config.return_value = MagicMock()
        
        mock_tokenizer_instance = MagicMock()
        mock_tokenizer_instance.pad_token = '<pad>'
        mock_tokenizer_instance.eos_token = '<eos>'
        mock_tokenizer_instance.pad_token_id = 0
        mock_tokenizer_instance.eos_token_id = 1
        mock_tokenizer_instance.encode.return_value = torch.tensor([[1, 2, 3]])
        mock_tokenizer_instance.decode.return_value = "Prompt: Analysis: The findings suggest a TI-RADS 3 nodule with moderate risk."
        mock_tokenizer.return_value = mock_tokenizer_instance
        
        mock_model_instance = MagicMock()
        mock_model_instance.generate.return_value = torch.tensor([[1, 2, 3, 4, 5, 6, 7, 8]])
        mock_model.return_value = mock_model_instance
        
        # Crear modelo LLM
        llm_model = ASTRAILLMModel(
            model_name='test_model',
            use_quantization=False,
            use_lora=False
        )
        
        # Preparar hallazgos de prueba
        findings = {
            'num_nodules': 2,
            'max_nodule_size': 12.5,
            'tirads': 3,
            'calcifications': True,
            'echogenicity': 'hypoechoic',
            'margins': 'irregular'
        }
        
        # Probar diferentes tipos de análisis
        analysis_types = ['analysis', 'risk_assessment', 'differential_diagnosis']
        
        for analysis_type in analysis_types:
            if analysis_type == 'differential_diagnosis':
                test_findings = {
                    'clinical_findings': 'Palpable nodule',
                    'imaging_findings': findings
                }
            else:
                test_findings = findings
            
            result = llm_model.generate_medical_analysis(
                test_findings,
                analysis_type=analysis_type,
                max_length=256
            )
            
            self.assertIsInstance(result, str)
            self.assertGreater(len(result), 0)

    def test_end_to_end_pipeline(self):
        """Prueba el pipeline completo de extremo a extremo."""
        # 1. Cargar datos
        dataset = ThyroidDataset(
            data_dir=self.test_data_dir,
            target_size=(256, 256),
            max_samples=1
        )
        
        image, target = dataset[0]
        
        # 2. Inferencia CNN
        cnn_model = ThyroidSegmentationModel(num_classes=4, pretrained=False)
        cnn_model.eval()
        
        with torch.no_grad():
            # Agregar dimensión de batch
            image_batch = image.unsqueeze(0)
            segmentation = cnn_model(image_batch)
            mask = torch.argmax(segmentation, dim=1).squeeze()
        
        # 3. Extraer características de la segmentación
        unique_classes, counts = torch.unique(mask, return_counts=True)
        
        # Simular análisis de nódulos
        nodule_pixels = (mask == 2).sum().item()  # Clase 2 = nódulos
        calc_pixels = (mask == 3).sum().item()    # Clase 3 = calcificaciones
        
        # Estimar tamaño de nódulos (simplificado)
        total_pixels = mask.numel()
        nodule_percentage = (nodule_pixels / total_pixels) * 100
        
        # 4. Preparar hallazgos para LLM
        findings = {
            'num_nodules': 1 if nodule_pixels > 0 else 0,
            'nodule_percentage': nodule_percentage,
            'has_calcifications': calc_pixels > 0,
            'tirads': target['tirads'].item() + 1 if target else 3,  # Convertir de índice a TI-RADS
            'image_size': mask.shape
        }
        
        # 5. Verificar que el pipeline produce resultados coherentes
        self.assertIsInstance(findings['num_nodules'], int)
        self.assertGreaterEqual(findings['num_nodules'], 0)
        self.assertIsInstance(findings['nodule_percentage'], float)
        self.assertGreaterEqual(findings['nodule_percentage'], 0.0)
        self.assertLessEqual(findings['nodule_percentage'], 100.0)
        self.assertIsInstance(findings['has_calcifications'], bool)
        self.assertGreaterEqual(findings['tirads'], 1)
        self.assertLessEqual(findings['tirads'], 5)

    def test_error_handling_pipeline(self):
        """Prueba el manejo de errores en el pipeline."""
        # Probar con directorio inexistente
        with self.assertRaises(Exception):
            dataset = ThyroidDataset(data_dir="/nonexistent/path")
        
        # Probar con imagen corrupta
        corrupt_image_path = os.path.join(self.test_data_dir, "corrupt.png")
        with open(corrupt_image_path, 'w') as f:
            f.write("not an image")
        
        dataset = ThyroidDataset(data_dir=self.test_data_dir)
        
        # El dataset debe manejar la imagen corrupta gracefully
        # (retornando tensor vacío en lugar de fallar)
        for i in range(len(dataset)):
            image, target = dataset[i]
            self.assertIsInstance(image, torch.Tensor)
            # target puede ser None para imágenes corruptas

    def test_batch_processing_pipeline(self):
        """Prueba el procesamiento en lotes."""
        from torch.utils.data import DataLoader
        
        # Crear dataset
        dataset = ThyroidDataset(
            data_dir=self.test_data_dir,
            target_size=(256, 256)
        )
        
        # Función collate personalizada para manejar targets None
        def custom_collate(batch):
            images = []
            targets = []
            
            for image, target in batch:
                images.append(image)
                if target is not None:
                    targets.append(target)
            
            if len(images) == 0:
                return None, None
            
            images = torch.stack(images)
            
            if len(targets) == 0:
                return images, None
            
            # Apilar targets
            batch_targets = {}
            for key in targets[0].keys():
                if key in ['seg_mask', 'tirads']:
                    batch_targets[key] = torch.stack([t[key] for t in targets])
                else:
                    batch_targets[key] = [t[key] for t in targets]
            
            return images, batch_targets
        
        # Crear DataLoader
        dataloader = DataLoader(
            dataset,
            batch_size=2,
            shuffle=False,
            collate_fn=custom_collate
        )
        
        # Probar carga en lotes
        for batch_images, batch_targets in dataloader:
            if batch_images is not None:
                self.assertIsInstance(batch_images, torch.Tensor)
                self.assertEqual(batch_images.shape[1:], (3, 256, 256))
                
                if batch_targets is not None:
                    self.assertIn('seg_mask', batch_targets)
                    self.assertIn('tirads', batch_targets)
            break  # Solo probar el primer lote

if __name__ == '__main__':
    unittest.main()

